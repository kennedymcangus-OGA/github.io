-- OFA Community Jobs v1.1.0.0 payment beta | Ozzy & Angus, Oceanic Gaming Australia
-- Community jobs: verified server payouts only after admin approval; no automatic delivery detection.
OFAJobs = {
    visible=false, adminView=false, selected=1, templateChoice=1,
    jobs={}, nextId=1, autoEnabled=true, isAdmin=false,
    rewards={1500,2000,1200,1600,1800},
    completed={}, payoutHolds={}, lastCompletion='',
    cursorPrevious=false, lastSaveOk=false, hotkeyIds={}, tick=0, lastGeneration=0,
    noticeText=nil, noticeUntil=0,
    templates={
        'TRANSPORT | Grain haul', 'FARMING | Harvest assistance',
        'SUPPORT | Fuel delivery', 'TRANSPORT | Pallet delivery',
        'FARMING | Bale collection'
    }
}
local VERSION='[OFA-JOBS-V04] '
local function log(m) print(VERSION..tostring(m)) end
-- Use the FS25 engine's real calendar date, not the simulated game time.
-- getDateDiffSeconds returns a signed difference depending on argument order.
-- v0.4.2 incorrectly rejected negative values. Do not make time-based jobs
-- if the engine clock cannot be verified; never silently use game-time.
local clockReason='not checked'
local function now()
    if type(getDate) ~= 'function' then
        clockReason='getDate unavailable'; return 0
    end
    if type(getDateDiffSeconds) ~= 'function' then
        clockReason='getDateDiffSeconds unavailable'; return 0
    end
    -- Call the engine directly so any API error remains visible in the game log.
    local dateString=getDate('%Y/%m/%d %H:%M')
    if type(dateString)~='string' then
        clockReason='getDate returned non-string: '..tostring(dateString); return 0
    end
    local yy,mm,dd,hh,mi=string.match(dateString,'^(%d%d%d%d)/(%d%d?)/(%d%d?) (%d%d?):(%d%d?)$')
    yy,mm,dd,hh,mi=tonumber(yy),tonumber(mm),tonumber(dd),tonumber(hh),tonumber(mi)
    if not (yy and mm and dd and hh and mi) or yy<2020 or yy>2100 or mm<1 or mm>12
        or dd<1 or dd>31 or hh>23 or mi>59 then
        clockReason='invalid date format/value: '..dateString; return 0
    end
    local result=getDateDiffSeconds(2020,1,1,0,0,0,yy,mm,dd,hh,mi,0)
    if type(result)~='number' or result~=result then
        clockReason='getDateDiffSeconds returned invalid value: '..tostring(result); return 0
    end
    result=math.abs(result)
    if result<86400 then
        clockReason='implausibly small date difference: '..tostring(result); return 0
    end
    clockReason='OK: '..dateString..' diffSeconds='..tostring(result)
    return math.floor(result)
end
local function limitText(s,n) return string.sub(tostring(s or ''),1,n) end
local function validNum(i,lo,hi) return type(i)=='number' and i==math.floor(i) and i>=lo and i<=hi end
local function hasMission() return g_currentMission ~= nil and g_currentMission.missionInfo ~= nil end
local function isServer() return g_server ~= nil end
local function canDraw()
    if g_dedicatedServer ~= nil or g_currentMission == nil then return false end
    if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return false end
    return true
end
local function getUser(connection)
    local mission=g_currentMission
    if mission==nil or mission.userManager==nil or connection==nil then return nil end
    return mission.userManager:getUserByConnection(connection)
end
local function userKey(user)
    if user==nil or user.getUniqueUserId==nil then return nil end
    local id=user:getUniqueUserId()
    if id==nil or tostring(id)=='' then return nil end
    return limitText(id,128)
end
local function admin(user)
    return user~=nil and user.getIsMasterUser~=nil and user:getIsMasterUser()==true
end
local function savePath()
    if not hasMission() then return nil end
    local dir=g_currentMission.missionInfo.savegameDirectory
    if type(dir)~='string' or dir=='' then return nil end
    return dir..'/ofaCommunityJobs.xml'
end
local function countJobs(t) return #(t or {}) end
function OFAJobs:persist()
    if not isServer() then return false end
    local path=savePath()
    if path==nil or createXMLFile==nil then
        log('WARNING: no savegame directory/XML API; records remain in server memory')
        return false
    end
    local xml=createXMLFile('ofaCommunityJobs',path,'ofaCommunityJobs')
    if xml==nil or xml==0 then log('WARNING: could not create job XML'); return false end
    setXMLInt(xml,'ofaCommunityJobs#schema',2)
    setXMLInt(xml,'ofaCommunityJobs#nextId',self.nextId)
    setXMLBool(xml,'ofaCommunityJobs#autoEnabled',self.autoEnabled)
    setXMLString(xml,'ofaCommunityJobs#lastGeneration',tostring(self.lastGeneration))
    for i,j in ipairs(self.jobs) do
        local root=string.format('ofaCommunityJobs.job(%d)',i-1)
        setXMLInt(xml,root..'#id',j.id)
        setXMLInt(xml,root..'#template',j.template)
        setXMLInt(xml,root..'#source',j.source)
        setXMLBool(xml,root..'#claimed',j.claimed)
        setXMLString(xml,root..'#owner',j.owner or '')
        setXMLString(xml,root..'#ownerKey',j.ownerKey or '')
        setXMLString(xml,root..'#expires',tostring(j.expires or 0))
        setXMLBool(xml,root..'#pending',j.pending==true)
        setXMLInt(xml,root..'#farmId',j.farmId or 0)
        setXMLInt(xml,root..'#reward',j.reward or self.rewards[j.template] or 0)
    end
    -- Completed-job records and payout holds survive restarts.
    for i,h in ipairs(self.completed) do
        local key=string.format('ofaCommunityJobs.completed(%d)',i-1)
        setXMLInt(xml,key..'#id',h.id)
        setXMLString(xml,key..'#owner',h.owner or '')
        setXMLInt(xml,key..'#farmId',h.farmId or 0)
        setXMLInt(xml,key..'#reward',h.reward or 0)
        setXMLString(xml,key..'#state',h.state or '')
    end
    saveXMLFile(xml)
    delete(xml)
    self.lastSaveOk=true
    return true
end
function OFAJobs:loadPersisted()
    if not isServer() then return end
    local path=savePath()
    if path==nil or fileExists==nil or not fileExists(path) then
        log('No existing OFA job file; starting clean')
        return
    end
    local xml=loadXMLFile('ofaCommunityJobs',path)
    if xml==nil or xml==0 then
        log('ERROR: existing job XML unreadable; automatic generation paused, leaving file untouched')
        self.autoEnabled=false
        return
    end
    local schema=getXMLInt(xml,'ofaCommunityJobs#schema')
    if schema~=1 and schema~=2 then
        delete(xml)
        log('ERROR: unsupported saved schema; auto generation paused (file preserved)')
        self.autoEnabled=false
        return
    end
    local loaded={}
    local seen={}
    local malformed=false
    for i=0,4 do
        local root=string.format('ofaCommunityJobs.job(%d)',i)
        if not hasXMLProperty(xml,root) then break end
        local id=getXMLInt(xml,root..'#id')
        local template=getXMLInt(xml,root..'#template')
        local source=getXMLInt(xml,root..'#source')
        local expiry=tonumber(getXMLString(xml,root..'#expires') or '')
        if not validNum(id,1,65535) or seen[id] or not validNum(template,1,#self.templates)
            or not validNum(source,1,2) or expiry==nil then
            malformed=true; break
        end
        seen[id]=true
        local claimed=getXMLBool(xml,root..'#claimed')==true
        local owner=limitText(getXMLString(xml,root..'#owner'),32)
        local key=limitText(getXMLString(xml,root..'#ownerKey'),128)
        if claimed and key=='' then malformed=true; break end
        local reward=(schema==2 and getXMLInt(xml,root..'#reward')) or self.rewards[template]
        if not validNum(reward,0,60000) then malformed=true;break end
        local farmId=(schema==2 and getXMLInt(xml,root..'#farmId')) or 0
        if not validNum(farmId,0,255) then malformed=true;break end
        loaded[#loaded+1]={id=id,template=template,source=source,
            expires=expiry,claimed=claimed,owner=owner,ownerKey=key,
            pending=(schema==2 and getXMLBool(xml,root..'#pending')==true) or false,
            farmId=farmId,reward=reward}
    end
    local completed={}
    if schema==2 then
        for i=0,49 do
            local root=string.format('ofaCommunityJobs.completed(%d)',i)
            if not hasXMLProperty(xml,root) then break end
            local id=getXMLInt(xml,root..'#id')
            local amount=getXMLInt(xml,root..'#reward') or 0
            local farmId=getXMLInt(xml,root..'#farmId') or 0
            local state=getXMLString(xml,root..'#state') or ''
            if not validNum(id,1,65535) or not validNum(amount,0,60000)
                or not validNum(farmId,0,255) or (state~='PAID' and state~='HOLD') then
                malformed=true;break
            end
            completed[#completed+1]={id=id,owner=limitText(getXMLString(xml,root..'#owner'),32),
                farmId=farmId,reward=amount,state=state}
        end
    end
    local nextId=getXMLInt(xml,'ofaCommunityJobs#nextId') or 1
    local automatic=getXMLBool(xml,'ofaCommunityJobs#autoEnabled')
    local generation=tonumber(getXMLString(xml,'ofaCommunityJobs#lastGeneration') or '0') or 0
    delete(xml)
    if malformed then
        self.autoEnabled=false
        log('ERROR: invalid saved job records; file preserved; auto generation paused')
        return
    end
    self.jobs=loaded
    self.completed=completed
    self.payoutHolds={}
    for _,h in ipairs(completed) do
        if h.state=='HOLD' then
            self.payoutHolds[h.id]=true
            log('PAYMENT HOLD: Job '..h.id..' payout outcome requires manual reconciliation; never auto-retrying')
        end
    end
    self.nextId=math.max(1,nextId)
    for _,j in ipairs(loaded) do self.nextId=math.max(self.nextId,j.id+1) end
    self.autoEnabled=(automatic==true)
    self.lastGeneration=generation
    log('Restored '..#loaded..' active jobs and '..#completed..' completion records')
end
function OFAJobs:pruneExpired()
    if not isServer() then return false end
    local stamp=now()
    if stamp<=0 then return false end
    local changed=false
    for i=#self.jobs,1,-1 do
        local j=self.jobs[i]
        if j.expires>0 and j.expires<=stamp then
            log('Expired job '..j.id..' (server UTC-relative second='..tostring(stamp)..')')
            table.remove(self.jobs,i)
            changed=true
        end
    end
    if changed then self:persist(); self:sendSnapshot() end
    return changed
end
function OFAJobs:addJob(template,source)
    if not validNum(template,1,#self.templates) or countJobs(self.jobs)>=5 then return false end
    if self.nextId>65535 then log('Job ID limit reached; restart IDs require migration'); return false end
    local stamp=now()
    if stamp<=0 then log('Clock unavailable; rejecting job creation ('..clockReason..')'); return false end
    local j={id=self.nextId,template=template,source=source or 1,
        claimed=false,owner='',ownerKey='',farmId=0,pending=false,
        reward=self.rewards[template],expires=stamp+12*3600}
    self.nextId=self.nextId+1
    self.jobs[#self.jobs+1]=j
    self:persist()
    self:sendSnapshot()
    log('Published job '..j.id..' from template '..template)
    return true
end
function OFAJobs:autoGenerate()
    if not isServer() or not self.autoEnabled then return end
    -- Limit automatic jobs to two, leaving three positions for admin-created work.
    local automatic=0
    for _,j in ipairs(self.jobs) do if j.source==2 then automatic=automatic+1 end end
    local changed=false
    while automatic<2 and #self.jobs<5 do
        -- Alternate among three simple approved starter templates.
        local start=((self.nextId-1)%#self.templates)+1
        local tpl=start
        -- Prefer a template that is not already shown; preserve the two-auto-job cap.
        for offset=0,#self.templates-1 do
            local candidate=((start+offset-1)%#self.templates)+1
            local used=false
            for _,existing in ipairs(self.jobs) do
                if existing.template==candidate then used=true; break end
            end
            if not used then tpl=candidate;break end
        end
        if not self:addJob(tpl,2) then break end
        automatic=automatic+1
        changed=true
    end
    if changed then log('Filled approved automatic-job slots') end
end
function OFAJobs:sendSnapshot(connection)
    if not isServer() then return end
    local data={jobs=self.jobs,autoEnabled=self.autoEnabled,lastCompletion=self.lastCompletion}
    if connection~=nil then connection:sendEvent(OFAJobsEvent.new(100,0,data))
    else g_server:broadcastEvent(OFAJobsEvent.new(100,0,data)) end
end
function OFAJobs:receiveSnapshot(data)
    self.jobs=data.jobs or {}
    self.autoEnabled=data.autoEnabled==true
    self.lastCompletion=data.lastCompletion or ''
    if self.selected>#self.jobs then self.selected=math.max(1,#self.jobs) end
    log('Received server snapshot: '..#self.jobs..' active jobs')
end
-- Resolve the claimant's farm on the server, never from client-supplied data.
local function farmForUser(user)
    if user==nil or user.getId==nil or g_farmManager==nil or g_farmManager.getFarmByUserId==nil then return 0 end
    local farm=g_farmManager:getFarmByUserId(user:getId())
    if farm==nil then return 0 end
    local farmId=(farm.getId~=nil and farm:getId()) or farm.farmId
    if not validNum(farmId,1,255) then return 0 end
    if FarmManager~=nil and farmId==FarmManager.SPECTATOR_FARM_ID then return 0 end
    return farmId
end
function OFAJobs:approveCompletion(job)
    if job==nil or not job.claimed or not job.pending then return false end
    if self.payoutHolds[job.id] then log('PAYMENT DENIED: job in payout hold');return false end
    local amount=job.reward or 0
    local farmId=job.farmId or 0
    if not validNum(amount,1,60000) or not validNum(farmId,1,255) then
        log('PAYMENT DENIED: invalid reward or claimant farm');return false
    end
    if g_currentMission==nil or g_currentMission.addMoney==nil or MoneyType==nil or MoneyType.OTHER==nil then
        log('PAYMENT DENIED: mission money API unavailable');return false
    end
    if g_farmManager==nil or g_farmManager.getFarmById==nil or g_farmManager:getFarmById(farmId)==nil then
        log('PAYMENT DENIED: target farm no longer exists');return false
    end
    -- Record HOLD before invoking the economy API. If the process crashes or the
    -- game is interrupted during the transfer, do NOT auto-retry: inspect funds.
    local record={id=job.id,owner=job.owner,farmId=farmId,reward=amount,state='HOLD'}
    self.completed[#self.completed+1]=record
    while #self.completed>50 do table.remove(self.completed,1) end
    self.payoutHolds[job.id]=true
    if not self:persist() then
        table.remove(self.completed,#self.completed)
        self.payoutHolds[job.id]=nil
        log('PAYMENT DENIED: could not persist payout hold')
        return false
    end
    -- Paid to a FARM, not an individual player wallet. Only the server executes it.
    g_currentMission:addMoney(amount,farmId,MoneyType.OTHER,true,true)
    record.state='PAID'
    self.payoutHolds[job.id]=nil
    for i,j in ipairs(self.jobs) do
        if j.id==job.id then table.remove(self.jobs,i);break end
    end
    self.lastCompletion='Job '..job.id..' COMPLETED / $'..amount..' to farm '..farmId
    self:persist()
    self:sendSnapshot()
    log('PAYMENT COMPLETED: job='..job.id..' farm='..farmId..' amount='..amount)
    return true
end
function OFAJobs:handleRequest(connection,kind,slot)
    if not isServer() then return end
    local user=getUser(connection)
    local key=userKey(user)
    if key==nil then log('Denied unauthenticated request'); return end
    if not validNum(kind,1,8) then log('Denied invalid request code '..tostring(kind)); return end
    log('Received user request kind='..tostring(kind)..' slot='..tostring(slot))
    if kind==1 then
        if not validNum(slot,1,#self.jobs) then return end
        local job=self.jobs[slot]
        if job.claimed then
            if job.ownerKey~=key then log('Denied foreign claim release'); self:sendSnapshot(connection);return end
            job.claimed=false; job.owner=''; job.ownerKey='';job.pending=false;job.farmId=0
            log('Released job '..job.id)
        else
            for _,other in ipairs(self.jobs) do
                if other.claimed and other.ownerKey==key then
                    log('Denied: already has a job'); self:sendSnapshot(connection);return
                end
            end
            job.claimed=true
            job.owner=limitText(user.getNickname~=nil and user:getNickname() or 'Farmer',24)
            job.ownerKey=key
            job.farmId=farmForUser(user)
            job.pending=false
            log('Claimed job '..job.id..' by '..job.owner)
        end
    elseif kind==7 then -- claimant requests completion; no money until admin approves
        if validNum(slot,1,#self.jobs) then
            local job=self.jobs[slot]
            if job.claimed and job.ownerKey==key and job.farmId>0 and not job.pending then
                job.pending=true
                log('COMPLETION REQUEST: job '..job.id..' awaiting administrator approval')
            else log('COMPLETION DENIED: not claimant / pending / invalid farm') end
        end
    else
        if not admin(user) then
            log('DENIED admin operation from non-admin account')
            self:sendSnapshot(connection)
            return
        end
        if kind==2 then -- create selected preset template
            if #self.jobs>=5 then
                log('BOARD FULL: Admin create rejected; maximum 5 active jobs')
            elseif not self:addJob(slot,1) then
                log('Admin create denied (invalid template / clock / ID limit)')
            end
        elseif kind==3 then -- cancel indexed job
            if validNum(slot,1,#self.jobs) then
                log('Admin cancelled job '..self.jobs[slot].id)
                table.remove(self.jobs,slot)
            end
        elseif kind==4 then -- release indexed job
            if validNum(slot,1,#self.jobs) then
                self.jobs[slot].claimed=false
                self.jobs[slot].owner=''
                self.jobs[slot].ownerKey=''
                self.jobs[slot].pending=false
                self.jobs[slot].farmId=0
                log('Admin released job slot '..slot)
            end
        elseif kind==5 then
            self.autoEnabled=not self.autoEnabled
            log('Admin auto jobs '..(self.autoEnabled and 'ON' or 'OFF'))
        elseif kind==6 then -- immediate auto-generation controlled server-side
            self:autoGenerate()
        elseif kind==8 then -- id-based approval prevents double-click paying a shifted slot
            local matching=nil
            for _,j in ipairs(self.jobs) do
                if j.id==slot then matching=j;break end
            end
            if matching~=nil and not self:approveCompletion(matching) then
                log('APPROVAL DENIED: job not pending or payout unavailable')
            elseif matching==nil then
                log('APPROVAL DENIED: job ID not found '..tostring(slot))
            end
        end
    end
    self:persist()
    self:sendSnapshot()
end
function OFAJobs:request(kind,slot)
    if g_client~=nil and g_client.getServerConnection~=nil then
        local c=g_client:getServerConnection()
        if c~=nil then
            log('Sending request kind='..tostring(kind)..' slot='..tostring(slot))
            c:sendEvent(OFAJobsEvent.new(kind,slot or 0))
        else log('WARNING: no server connection for request') end
    elseif isServer() then log('Local admin UI requires client connection') end
end
function OFAJobs:toggle()
    if not canDraw() then return end
    self.visible=not self.visible
    if g_inputBinding~=nil and g_inputBinding.setShowMouseCursor~=nil then
        if self.visible then
            self.cursorPrevious=g_inputBinding.getShowMouseCursor~=nil and g_inputBinding:getShowMouseCursor() or false
            g_inputBinding:setShowMouseCursor(true)
        else g_inputBinding:setShowMouseCursor(self.cursorPrevious) end
    end
    log(self.visible and 'Board opened' or 'Board closed')
end
function OFAJobs:actionMenu(_,v) if v==nil or v>0 then self:toggle() end end
-- Register through the owning player's input context when available. Some
-- multiplayer clients have no g_currentMission.player object (only playerSystem).
-- Therefore do not gate registration on that particular field.
function OFAJobs:registerHotkey(origin)
    if self.hotkeyRegistered then return end
    if g_client==nil or g_inputBinding==nil then
        if not self.hotkeyMissingReported and g_currentMission~=nil then
            log('INPUT WAIT: no local client or input binding yet')
            self.hotkeyMissingReported=true
        end
        return
    end
    if g_currentMission==nil then return end
    if g_inputBinding.registerActionEvent==nil then
        if not self.hotkeyMissingReported then log('INPUT ERROR: registerActionEvent unavailable') end
        self.hotkeyMissingReported=true
        return
    end
    self.hotkeyAttempts=(self.hotkeyAttempts or 0)+1
    local action=InputAction~=nil and InputAction.OFA_JOBS_MENU or nil
    if action==nil then
        -- Some modded actions are accepted by name even if the enum has not
        -- been copied into InputAction on this client build.
        action='OFA_JOBS_MENU'
        if self.hotkeyAttempts==1 then log('INPUT INFO: missing InputAction enum; trying named action') end
    end
    -- Register directly; script errors must not be silently hidden from GIANTS logs.
    local ok,id=g_inputBinding:registerActionEvent(
        action,self,self.actionMenu,false,true,false,true)
    if ok and id~=nil then
        self.hotkeyRegistered=true
        self.hotkeyIds[id]=true
        if g_inputBinding.setActionEventText~=nil then
            g_inputBinding:setActionEventText(id,'OFA Jobs: Open board')
        end
        log('INPUT READY: OFA_JOBS_MENU registered from '..tostring(origin)..' id='..tostring(id))
    elseif self.hotkeyAttempts==1 or self.hotkeyAttempts==60 then
        log('INPUT ERROR: from='..tostring(origin)..
            ' result='..tostring(ok)..' id='..tostring(id)..
            ' enum='..tostring(InputAction~=nil and InputAction.OFA_JOBS_MENU))
    end
end
if PlayerInputComponent~=nil and PlayerInputComponent.registerGlobalPlayerActionEvents~=nil
        and Utils~=nil and Utils.appendedFunction~=nil then
    PlayerInputComponent.registerGlobalPlayerActionEvents=Utils.appendedFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,function(component)
            if component~=nil and component.player~=nil and component.player.isOwner then
                -- This hook executes in the player's active input context.
                OFAJobs:registerHotkey('player-context')
            end
        end)
    log('INPUT HOOK: player context installed')
else
    log('INPUT HOOK: unavailable; will retry from update')
end
if FSBaseMission~=nil and FSBaseMission.onConnectionFinishedLoading~=nil then
    FSBaseMission.onConnectionFinishedLoading=Utils.appendedFunction(
        FSBaseMission.onConnectionFinishedLoading,function(_,connection)
            if isServer() and connection~=nil then OFAJobs:sendSnapshot(connection) end
        end)
end
if FSBaseMission~=nil and FSBaseMission.saveSavegame~=nil then
    FSBaseMission.saveSavegame=Utils.appendedFunction(
        FSBaseMission.saveSavegame,function(_) if isServer() then OFAJobs:persist() end end)
end
local function within(x,y,x0,y0,x1,y1) return x>=x0 and x<=x1 and y>=y0 and y<=y1 end
function OFAJobs:mouseEvent(x,y,isDown,_,button)
    if not canDraw() or not isDown or button~=1 or not self.visible then return end
    if g_inputBinding==nil or g_inputBinding.getShowMouseCursor==nil
        or not g_inputBinding:getShowMouseCursor() then return end
    if within(x,y,0.922,0.817,0.970,0.855) then self:toggle();return end
    if within(x,y,0.619,0.751,0.775,0.788) then self.adminView=false;return end
    if within(x,y,0.784,0.751,0.955,0.788) and self.isAdmin then self.adminView=true;return end
    if not self.adminView then
        for i=1,5 do
            local bottom=0.670-(i-1)*0.057
            if within(x,y,0.620,bottom,0.960,bottom+0.051) then self.selected=i;return end
        end
        if within(x,y,0.620,0.350,0.783,0.402) then self:request(1,self.selected)
        elseif within(x,y,0.793,0.350,0.955,0.402) then self:request(7,self.selected) end
    elseif self.isAdmin then
        for i=1,5 do
            local bottom=0.670-(i-1)*0.057
            if within(x,y,0.620,bottom,0.960,bottom+0.051) then self.templateChoice=i;return end
        end
        if within(x,y,0.620,0.407,0.780,0.453) then
            if #self.jobs>=5 then
                self.noticeText='BOARD FULL - MAXIMUM 5 ACTIVE JOBS'
                self.noticeUntil=6000
                log('BOARD FULL: Create button blocked locally; 5 active jobs')
            else
                self.noticeText='CREATE REQUEST SENT'
                self.noticeUntil=2500
                self:request(2,self.templateChoice)
            end
        elseif within(x,y,0.791,0.407,0.959,0.453) then self:request(5,0)
        elseif within(x,y,0.620,0.351,0.726,0.398) then self:request(4,self.selected)
        elseif within(x,y,0.734,0.351,0.840,0.398) then self:request(3,self.selected)
        elseif within(x,y,0.847,0.351,0.959,0.398) then
            local job=self.jobs[self.selected]
            if job~=nil and job.pending then self:request(8,job.id)
            else log('APPROVAL WAIT: select an awaiting-admin job on Jobs Board') end
        end
    end
end
function OFAJobs:loadMap()
    self.visible=false; self.adminView=false; self.jobs={};self.selected=1
    self.noticeText=nil; self.noticeUntil=0
    self.hotkeyRegistered=false;self.hotkeyMissingReported=false;self.hotkeyAttempts=0;self.inputRetryMs=0
    if isServer() then
        local clockValue=now()
        log(clockValue>0 and ('Engine clock READY: '..clockReason..' | relativeSeconds='..clockValue) or 'ERROR: FS25 engine clock unavailable; jobs disabled ('..clockReason..')')
        self:loadPersisted()
        self:pruneExpired()
        self:autoGenerate()
    end
    log('v1.1 PAYMENT BETA: admin-approved completion; server farm reward; v1.0 input and 12h expiry retained')
end
function OFAJobs:update(dt)
    if self.noticeUntil>0 then
        self.noticeUntil=math.max(0,self.noticeUntil-(dt or 0))
        if self.noticeUntil==0 then self.noticeText=nil end
    end
    if isServer() then
        self.tick=self.tick+(dt or 0)
        if self.tick>=60000 then
            self.tick=0
            self:pruneExpired()
            self:autoGenerate()
        end
    end
    if g_client~=nil and g_currentMission~=nil then
        self.isAdmin=g_currentMission.isMasterUser==true
        -- Retry at most once per second; the owning player field can be nil
        -- even after the HUD starts rendering in a multiplayer session.
        if not self.hotkeyRegistered then
            self.inputRetryMs=(self.inputRetryMs or 0)+(dt or 0)
            if self.inputRetryMs>=1000 then
                self.inputRetryMs=0
                self:registerHotkey('update-fallback')
            end
        end
    end
end
local function rect(x,y,w,h,r,g,b,a) if drawFilledRect~=nil then drawFilledRect(x,y,w,h,r,g,b,a) end end
local function txt(x,y,s,t,r,g,b)
    if renderText==nil then return end
    if setTextColor~=nil then setTextColor(r,g,b,1) end
    renderText(x,y,s,t)
end
function OFAJobs:draw()
    if not canDraw() or renderText==nil then return end
    local available=0
    for _,j in ipairs(self.jobs) do if not j.claimed then available=available+1 end end
    rect(0.832,0.774,0.147,0.058,0.03,0.06,0.08,0.84)
    rect(0.832,0.826,0.147,0.006,0.96,0.75,0.12,1)
    txt(0.843,0.801,0.016,'OFA JOBS',1,0.84,0.16)
    txt(0.843,0.783,0.012,tostring(available)..' AVAILABLE | Ctrl+Alt+J',1,1,1)
    if not self.visible then return end
    rect(0.605,0.338,0.375,0.537,0.025,0.04,0.06,0.95)
    rect(0.605,0.858,0.375,0.017,0.95,0.72,0.10,1)
    txt(0.624,0.824,0.021,'OFA COMMUNITY JOBS',1,0.83,0.16)
    rect(0.922,0.817,0.048,0.038,0.18,0.21,0.25,1)
    txt(0.938,0.827,0.016,'X',1,1,1)
    txt(0.624,0.795,0.012,'WILLOW RIVER | 5 JOB MAX | 12H EXPIRY',0.84,0.88,0.93)
    rect(0.619,0.751,0.158,0.038,not self.adminView and 0.66 or 0.14,0.48,0.12,1)
    txt(0.642,0.762,0.015,'JOBS BOARD',1,1,1)
    rect(0.783,0.751,0.174,0.038,self.adminView and 0.66 or 0.14,0.48,0.12,1)
    txt(0.801,0.762,0.014,self.isAdmin and 'ADMIN MANAGER' or 'ADMIN ONLY',1,1,1)
    if not self.adminView then
        for i=1,5 do
            local bottom=0.670-(i-1)*0.057
            local j=self.jobs[i]
            rect(0.619,bottom,0.338,0.052,i==self.selected and 0.25 or 0.10,
                i==self.selected and 0.22 or 0.14,0.12,0.96)
            if j~=nil then
                txt(0.630,bottom+0.030,0.013,limitText(self.templates[j.template] or '?',38),1,1,1)
                local status=j.pending and ('AWAITING ADMIN: '..j.owner) or (j.claimed and ('CLAIMED: '..j.owner) or 'AVAILABLE')
                txt(0.630,bottom+0.010,0.012,limitText(status..' | $'..tostring(j.reward or 0),47),j.claimed and 1 or 0.58,
                    j.claimed and 0.78 or 0.95,j.claimed and 0.26 or 0.64)
            else txt(0.630,bottom+0.018,0.013,'EMPTY JOB SLOT',0.55,0.62,0.67) end
        end
        rect(0.620,0.350,0.163,0.052,0.78,0.59,0.08,1)
        txt(0.628,0.371,0.013,'CLAIM / RELEASE',0.06,0.08,0.10)
        rect(0.793,0.350,0.162,0.052,0.18,0.57,0.39,1)
        txt(0.808,0.371,0.013,'MARK COMPLETE',1,1,1)
    else
        txt(0.625,0.717,0.013,'SELECT AN APPROVED JOB TEMPLATE:',0.85,0.87,0.91)
        if #self.jobs>=5 then
            txt(0.625,0.738,0.012,'BOARD FULL - MAXIMUM 5 ACTIVE JOBS',1,0.70,0.25)
        elseif self.noticeText~=nil and self.noticeUntil>0 then
            txt(0.625,0.738,0.012,self.noticeText,0.68,0.95,0.70)
        end
        for i=1,5 do
            local bottom=0.670-(i-1)*0.057
            rect(0.620,bottom,0.337,0.052,i==self.templateChoice and 0.32 or 0.10,0.20,0.12,0.95)
            txt(0.631,bottom+0.019,0.014,self.templates[i],1,1,1)
        end
        rect(0.620,0.407,0.161,0.046,0.75,0.55,0.09,1)
        txt(0.639,0.425,0.014,'CREATE JOB',0.06,0.08,0.10)
        rect(0.791,0.407,0.168,0.046,0.15,0.29,0.36,1)
        txt(0.803,0.425,0.013,'AUTO: '..(self.autoEnabled and 'ON' or 'OFF'),1,1,1)
        rect(0.620,0.351,0.106,0.046,0.23,0.37,0.30,1)
        txt(0.629,0.368,0.011,'RELEASE',1,1,1)
        rect(0.734,0.351,0.106,0.046,0.48,0.17,0.17,1)
        txt(0.747,0.368,0.011,'CANCEL',1,1,1)
        rect(0.847,0.351,0.112,0.046,0.18,0.57,0.39,1)
        txt(0.851,0.368,0.011,'APPROVE DONE',1,1,1)
    end
    if self.lastCompletion~='' then
        txt(0.625,0.339,0.011,self.lastCompletion,0.62,1,0.65)
    end
    if setTextColor~=nil then setTextColor(1,1,1,1) end
end
function OFAJobs:deleteMap()
    if self.visible and g_inputBinding~=nil and g_inputBinding.setShowMouseCursor~=nil then
        g_inputBinding:setShowMouseCursor(self.cursorPrevious)
    end
    self.visible=false
    if isServer() then self:persist() end
    log('Unloaded')
end
addModEventListener(OFAJobs)
