-- OFA v0.4: all mutations validated by server; client snapshots are read-only.
OFAJobsEvent = {}
local mt = Class(OFAJobsEvent, Event)
InitEventClass(OFAJobsEvent, 'OFAJobsEvent_' .. (g_currentModName or 'OFACommunityJobs'))
function OFAJobsEvent.emptyNew() return Event.new(mt) end
function OFAJobsEvent.new(kind, jobId, data)
    local e = OFAJobsEvent.emptyNew()
    e.kind, e.jobId, e.data = kind or 0, jobId or 0, data or {}
    return e
end
function OFAJobsEvent:writeStream(streamId, connection)
    streamWriteUInt8(streamId, self.kind)
    streamWriteUInt16(streamId, self.jobId)
    if self.kind == 100 then
        streamWriteBool(streamId, self.data.autoEnabled == true)
        streamWriteString(streamId, string.sub(tostring(self.data.lastCompletion or ''),1,96))
        streamWriteUInt8(streamId, math.min(#(self.data.jobs or {}), 5))
        for _,j in ipairs(self.data.jobs or {}) do
            streamWriteUInt16(streamId, j.id or 0)
            streamWriteUInt8(streamId, j.template or 1)
            streamWriteUInt8(streamId, j.source or 1)
            streamWriteBool(streamId, j.claimed == true)
            streamWriteString(streamId, string.sub(tostring(j.owner or ''),1,32))
            streamWriteString(streamId, tostring(j.expires or 0))
            streamWriteUInt8(streamId, j.pending == true and 1 or 0)
            streamWriteUInt16(streamId, j.reward or 0)
        end
    end
end
function OFAJobsEvent:readStream(streamId, connection)
    self.kind = streamReadUInt8(streamId)
    self.jobId = streamReadUInt16(streamId)
    self.data = {}
    if self.kind == 100 then
        self.data.autoEnabled = streamReadBool(streamId)
        self.data.lastCompletion = streamReadString(streamId)
        self.data.jobs = {}
        local count = math.min(streamReadUInt8(streamId),5)
        for i=1,count do
            self.data.jobs[i] = {
                id=streamReadUInt16(streamId),template=streamReadUInt8(streamId),
                source=streamReadUInt8(streamId),claimed=streamReadBool(streamId),
                owner=streamReadString(streamId),expires=tonumber(streamReadString(streamId)) or 0,
                pending=streamReadUInt8(streamId)==1, reward=streamReadUInt16(streamId)
            }
        end
    end
    self:run(connection)
end
function OFAJobsEvent:run(connection)
    if OFAJobs == nil then return end
    if self.kind == 100 then
        -- Only data from actual server is permitted to replace client state.
        if connection == nil or not connection:getIsServer() or g_server ~= nil then return end
        OFAJobs:receiveSnapshot(self.data)
    else
        if g_server == nil or connection == nil or connection:getIsServer() then return end
        OFAJobs:handleRequest(connection,self.kind,self.jobId)
    end
end
