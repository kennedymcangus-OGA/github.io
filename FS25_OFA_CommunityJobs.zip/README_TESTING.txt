OFA COMMUNITY JOBS v1.0.0.0 GIANTS VALIDATION CANDIDATE (based on v0.4.6 beta) (NOT FINAL / NOT GIANTS APPROVED)
Designed by Ozzy & Angus (Oceanic Gaming Australia)

FEATURES: 5 jobs max; admin create/cancel/release; player claim/release;
up to 2 automatic jobs; persisted server XML; 12 REAL-HOUR expiry;
Ctrl+Alt+J board; board-full notice; prefer different automatic templates.
No money, contract completion, or actual vehicle/crop/delivery progress tracking.

INSTALL:
1. Back up FS25_OFA_CommunityJobs.zip and your server savegame.
2. Stop game and server, then install identical package on BOTH sides.
3. Rename package to FS25_OFA_CommunityJobs.zip on each PC/server.
4. Remove other OFA Community Jobs ZIP variants from both mods folders.
5. Start and verify input, manual create, claim, release, cancel and persistence.
6. The full 12-hour expiry remains UNVERIFIED BY LIVE TEST until exercised.

The separate two-minute expiry TEST ZIP can validate the same cleanup code
on a disposable isolated savegame. Never run test ZIP on live Willow River.

GIANTS v0.9.24 report corrections: descriptor 116; 1.0.0.0 version; 512x512 DXT1 icon with convention; direct API calls in HUD instead of pcall. Gameplay must be retested after modifying error handling.
