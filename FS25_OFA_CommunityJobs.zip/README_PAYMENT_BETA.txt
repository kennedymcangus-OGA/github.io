OFA COMMUNITY JOBS v1.1.0.0 — PAYMENTS BETA (PC / DEDICATED SERVER)
Designed by Ozzy & Angus — Oceanic Gaming Australia

WARNING: TEST BUILD ONLY. DO NOT INSTALL ON LIVE WILLOW RIVER YET.
Create and back up a disposable savegame. Use exactly the same ZIP on client and server.

Open board: Left Ctrl + Left Alt + J
Player: select available job > CLAIM; perform community work; MARK COMPLETE.
Admin: select the awaiting-admin job on JOBS BOARD, then ADMIN MANAGER > APPROVE DONE.
On approval the dedicated server deposits the shown fixed reward into the claimants FARM balance.
Admin cancellation never pays. Releasing a claimed job never pays.
No physical delivery/harvest verification exists: completion is self-reported and admin approved.
Only a human admin should approve work after reviewing evidence.

Preset rewards (currency is the savegame currency):
Grain haul 1500; Harvest assistance 2000; Fuel delivery 1200; Pallet delivery 1600; Bale collection 1800.
Maximum 5 active jobs; automatic generation can be disabled; 12-hour real-world expiry.

Existing schema-1 XML jobs are migrated in memory to schema 2; BACK UP THE SAVEGAME FIRST.
PAYMENT HOLD: In case of a crash during payout, a held record is stored for manual reconciliation.
Check server log for PAYMENT COMPLETED. Test with a normal farm (not spectator).

IMPORTANT: This is not a ModHub-approved build. The earlier v1.0.0.0 passed TestRunner,
but these new Lua/network/payment changes require a fresh GIANTS test and in-game regression.
